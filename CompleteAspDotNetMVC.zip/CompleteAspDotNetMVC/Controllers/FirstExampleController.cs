﻿using CompleteAspDotNetMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CompleteAspDotNetMVC.Controllers
{
    public class FirstExampleController : Controller
    {
        public string HelloWorld() => "Hai Dileep";
        public double GetNumber(string v1,string v2)
        {
            var first = double.Parse(v1);
            var second = double.Parse(v2);
            return first + second;
        }

        public ViewResult DisplayEmployee()
        {
            Employee emp = new Employee
            {
                EmpId = 1,
                EmpName="Dileep",
                EmpAddress="ObireddygariPalli",
                EmpSalary=28000
            };
            return View(emp);
        }
    }
}